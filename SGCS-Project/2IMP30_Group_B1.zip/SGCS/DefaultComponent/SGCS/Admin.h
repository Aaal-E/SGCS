/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: Admin
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\Admin.h
*********************************************************************/

#ifndef Admin_H
#define Admin_H

//## auto_generated
#include <oxf.h>
//## package UCs

//## actor Admin
class Admin {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    Admin(void);
    
    //## auto_generated
    ~Admin(void);
};

#endif
/*********************************************************************
	File Path	: DefaultComponent\SGCS\Admin.h
*********************************************************************/
