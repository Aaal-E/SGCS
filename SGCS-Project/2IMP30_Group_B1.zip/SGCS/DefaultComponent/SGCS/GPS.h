/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: GPS
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\GPS.h
*********************************************************************/

#ifndef GPS_H
#define GPS_H

//## auto_generated
#include <oxf.h>
//## auto_generated
#include "BDD.h"
//## package BDD

//## class GPS
class GPS {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    GPS(void);
    
    //## auto_generated
    ~GPS(void);
};

#endif
/*********************************************************************
	File Path	: DefaultComponent\SGCS\GPS.h
*********************************************************************/
