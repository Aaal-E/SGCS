/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: block_39
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\block_39.h
*********************************************************************/

#ifndef block_39_H
#define block_39_H

//## auto_generated
#include <oxf.h>
//## auto_generated
#include "BDD.h"
//## package BDD

//## class block_39
class block_39 {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    block_39(void);
    
    //## auto_generated
    ~block_39(void);
};

#endif
/*********************************************************************
	File Path	: DefaultComponent\SGCS\block_39.h
*********************************************************************/
