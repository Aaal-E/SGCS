/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: part_0
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\part_0.h
*********************************************************************/

#ifndef part_0_H
#define part_0_H

//## auto_generated
#include <oxf.h>
//## auto_generated
#include "BDD.h"
//## package BDD

//## class TopLevel::part_0
class part_0_C {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    part_0_C(void);
    
    //## auto_generated
    ~part_0_C(void);
};

#endif
/*********************************************************************
	File Path	: DefaultComponent\SGCS\part_0.h
*********************************************************************/
