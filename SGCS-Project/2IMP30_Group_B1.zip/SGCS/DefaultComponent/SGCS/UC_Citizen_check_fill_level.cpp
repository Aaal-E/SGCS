/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: UC_Citizen_check_fill_level
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\UC_Citizen_check_fill_level.cpp
*********************************************************************/

//## auto_generated
#include "UC_Citizen_check_fill_level.h"
//## package BDD

//## class UC_Citizen_check_fill_level
UC_Citizen_check_fill_level::UC_Citizen_check_fill_level(void) {
}

UC_Citizen_check_fill_level::~UC_Citizen_check_fill_level(void) {
}

/*********************************************************************
	File Path	: DefaultComponent\SGCS\UC_Citizen_check_fill_level.cpp
*********************************************************************/
