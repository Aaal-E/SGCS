/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: Citizen
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\Citizen.cpp
*********************************************************************/

//## auto_generated
#include "Citizen.h"
//## package UCs

//## actor Citizen
Citizen::Citizen(void) {
}

Citizen::~Citizen(void) {
}

void Citizen::Pick_bin(void) {
    //#[ operation Pick_bin()
    //#]
}

void Citizen::Walk_to_bin(void) {
    //#[ operation Walk_to_bin()
    //#]
}

/*********************************************************************
	File Path	: DefaultComponent\SGCS\Citizen.cpp
*********************************************************************/
