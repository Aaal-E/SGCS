/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: UC_Collect_garbage
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\UC_Collect_garbage.cpp
*********************************************************************/

//## auto_generated
#include "UC_Collect_garbage.h"
//## package BDD

//## class UC_Collect_garbage
UC_Collect_garbage::UC_Collect_garbage(void) {
}

UC_Collect_garbage::~UC_Collect_garbage(void) {
}

/*********************************************************************
	File Path	: DefaultComponent\SGCS\UC_Collect_garbage.cpp
*********************************************************************/
