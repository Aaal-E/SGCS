/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: UC_System_overview
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\UC_System_overview.cpp
*********************************************************************/

//## auto_generated
#include "UC_System_overview.h"
//## package BDD

//## class UC_System_overview
UC_System_overview::UC_System_overview(void) {
}

UC_System_overview::~UC_System_overview(void) {
}

/*********************************************************************
	File Path	: DefaultComponent\SGCS\UC_System_overview.cpp
*********************************************************************/
