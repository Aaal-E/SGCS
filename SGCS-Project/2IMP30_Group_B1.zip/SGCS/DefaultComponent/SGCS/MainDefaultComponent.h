/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: SGCS
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\MainDefaultComponent.h
*********************************************************************/

#ifndef MainDefaultComponent_H
#define MainDefaultComponent_H

//## auto_generated
#include <oxf.h>
#endif
/*********************************************************************
	File Path	: DefaultComponent\SGCS\MainDefaultComponent.h
*********************************************************************/
