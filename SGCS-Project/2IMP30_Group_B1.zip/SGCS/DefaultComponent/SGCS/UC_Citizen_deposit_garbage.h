/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: UC_Citizen_deposit_garbage
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\UC_Citizen_deposit_garbage.h
*********************************************************************/

#ifndef UC_Citizen_deposit_garbage_H
#define UC_Citizen_deposit_garbage_H

//## auto_generated
#include <oxf.h>
//## auto_generated
#include "BDD.h"
//## package BDD

//## class UC_Citizen_deposit_garbage
class UC_Citizen_deposit_garbage {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    UC_Citizen_deposit_garbage(void);
    
    //## auto_generated
    ~UC_Citizen_deposit_garbage(void);
};

#endif
/*********************************************************************
	File Path	: DefaultComponent\SGCS\UC_Citizen_deposit_garbage.h
*********************************************************************/
