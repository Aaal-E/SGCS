/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: Admin
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\Admin.cpp
*********************************************************************/

//## auto_generated
#include "Admin.h"
//## package UCs

//## actor Admin
Admin::Admin(void) {
}

Admin::~Admin(void) {
}

/*********************************************************************
	File Path	: DefaultComponent\SGCS\Admin.cpp
*********************************************************************/
