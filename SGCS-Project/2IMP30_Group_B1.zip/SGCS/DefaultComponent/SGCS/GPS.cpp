/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: GPS
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\GPS.cpp
*********************************************************************/

//## auto_generated
#include "GPS.h"
//## package BDD

//## class GPS
GPS::GPS(void) {
}

GPS::~GPS(void) {
}

/*********************************************************************
	File Path	: DefaultComponent\SGCS\GPS.cpp
*********************************************************************/
