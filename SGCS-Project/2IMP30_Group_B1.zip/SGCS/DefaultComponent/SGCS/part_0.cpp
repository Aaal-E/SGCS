/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: part_0
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\part_0.cpp
*********************************************************************/

//## auto_generated
#include "part_0.h"
//## package BDD

//## class TopLevel::part_0
part_0_C::part_0_C(void) {
}

part_0_C::~part_0_C(void) {
}

/*********************************************************************
	File Path	: DefaultComponent\SGCS\part_0.cpp
*********************************************************************/
