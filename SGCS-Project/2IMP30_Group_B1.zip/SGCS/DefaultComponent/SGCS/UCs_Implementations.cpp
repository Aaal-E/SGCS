/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: UCs_Implementations
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\UCs_Implementations.cpp
*********************************************************************/

//## auto_generated
#include "UCs_Implementations.h"
//## package UCs_Implementations



//## event Receive_route()
Receive_route::Receive_route(void) : OMEvent() {
    setId(Receive_route_UCs_Implementations_id);
}

//#[ ignore
const IOxfEvent::ID Receive_route_UCs_Implementations_id(28801);
//#]

//## event Request_route()
Request_route::Request_route(void) : OMEvent() {
    setId(Request_route_UCs_Implementations_id);
}

//#[ ignore
const IOxfEvent::ID Request_route_UCs_Implementations_id(28802);
//#]

/*********************************************************************
	File Path	: DefaultComponent\SGCS\UCs_Implementations.cpp
*********************************************************************/
