/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: SGCS
	Model Element	: UC_Plan_route
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\SGCS\UC_Plan_route.h
*********************************************************************/

#ifndef UC_Plan_route_H
#define UC_Plan_route_H

//## auto_generated
#include <oxf.h>
//## auto_generated
#include "BDD.h"
//## package BDD

//## class UC_Plan_route
class UC_Plan_route {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    UC_Plan_route(void);
    
    //## auto_generated
    ~UC_Plan_route(void);
};

#endif
/*********************************************************************
	File Path	: DefaultComponent\SGCS\UC_Plan_route.h
*********************************************************************/
