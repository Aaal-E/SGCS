/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: Garbage_Bin_Simulation
	Model Element	: UC_Citizen_deposit_garbage
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\Garbage_Bin_Simulation\UC_Citizen_deposit_garbage.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "UC_Citizen_deposit_garbage.h"
//#[ ignore
#define BDD_UC_Citizen_deposit_garbage_UC_Citizen_deposit_garbage_SERIALIZE OM_NO_OP
//#]

//## package BDD

//## class UC_Citizen_deposit_garbage
UC_Citizen_deposit_garbage::UC_Citizen_deposit_garbage(void) {
    NOTIFY_CONSTRUCTOR(UC_Citizen_deposit_garbage, UC_Citizen_deposit_garbage(), 0, BDD_UC_Citizen_deposit_garbage_UC_Citizen_deposit_garbage_SERIALIZE);
}

UC_Citizen_deposit_garbage::~UC_Citizen_deposit_garbage(void) {
    NOTIFY_DESTRUCTOR(~UC_Citizen_deposit_garbage, true);
}

#ifdef _OMINSTRUMENT
IMPLEMENT_META_P(UC_Citizen_deposit_garbage, BDD, BDD, false, OMAnimatedUC_Citizen_deposit_garbage)
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: DefaultComponent\Garbage_Bin_Simulation\UC_Citizen_deposit_garbage.cpp
*********************************************************************/
