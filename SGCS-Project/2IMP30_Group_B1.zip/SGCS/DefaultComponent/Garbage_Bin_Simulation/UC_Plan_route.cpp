/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: Garbage_Bin_Simulation
	Model Element	: UC_Plan_route
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\Garbage_Bin_Simulation\UC_Plan_route.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "UC_Plan_route.h"
//#[ ignore
#define BDD_UC_Plan_route_UC_Plan_route_SERIALIZE OM_NO_OP
//#]

//## package BDD

//## class UC_Plan_route
UC_Plan_route::UC_Plan_route(void) {
    NOTIFY_CONSTRUCTOR(UC_Plan_route, UC_Plan_route(), 0, BDD_UC_Plan_route_UC_Plan_route_SERIALIZE);
}

UC_Plan_route::~UC_Plan_route(void) {
    NOTIFY_DESTRUCTOR(~UC_Plan_route, true);
}

#ifdef _OMINSTRUMENT
IMPLEMENT_META_P(UC_Plan_route, BDD, BDD, false, OMAnimatedUC_Plan_route)
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: DefaultComponent\Garbage_Bin_Simulation\UC_Plan_route.cpp
*********************************************************************/
