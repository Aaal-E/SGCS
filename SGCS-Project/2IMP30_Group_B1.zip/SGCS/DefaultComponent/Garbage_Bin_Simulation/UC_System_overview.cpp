/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: Garbage_Bin_Simulation
	Model Element	: UC_System_overview
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\Garbage_Bin_Simulation\UC_System_overview.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "UC_System_overview.h"
//#[ ignore
#define BDD_UC_System_overview_UC_System_overview_SERIALIZE OM_NO_OP
//#]

//## package BDD

//## class UC_System_overview
UC_System_overview::UC_System_overview(void) {
    NOTIFY_CONSTRUCTOR(UC_System_overview, UC_System_overview(), 0, BDD_UC_System_overview_UC_System_overview_SERIALIZE);
}

UC_System_overview::~UC_System_overview(void) {
    NOTIFY_DESTRUCTOR(~UC_System_overview, true);
}

#ifdef _OMINSTRUMENT
IMPLEMENT_META_P(UC_System_overview, BDD, BDD, false, OMAnimatedUC_System_overview)
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: DefaultComponent\Garbage_Bin_Simulation\UC_System_overview.cpp
*********************************************************************/
