/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: Garbage_Bin_Simulation
	Model Element	: Garbage_Bin_Simulation
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\Garbage_Bin_Simulation\MainDefaultComponent.h
*********************************************************************/

#ifndef MainDefaultComponent_H
#define MainDefaultComponent_H

//## auto_generated
#include <oxf.h>
//## auto_generated
#include <aom.h>
#endif
/*********************************************************************
	File Path	: DefaultComponent\Garbage_Bin_Simulation\MainDefaultComponent.h
*********************************************************************/
