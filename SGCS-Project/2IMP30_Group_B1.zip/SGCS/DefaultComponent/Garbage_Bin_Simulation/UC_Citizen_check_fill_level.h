/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: Garbage_Bin_Simulation
	Model Element	: UC_Citizen_check_fill_level
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\Garbage_Bin_Simulation\UC_Citizen_check_fill_level.h
*********************************************************************/

#ifndef UC_Citizen_check_fill_level_H
#define UC_Citizen_check_fill_level_H

//## auto_generated
#include <oxf.h>
//## auto_generated
#include <aom.h>
//## auto_generated
#include "BDD.h"
//## package BDD

//## class UC_Citizen_check_fill_level
class UC_Citizen_check_fill_level {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedUC_Citizen_check_fill_level;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    UC_Citizen_check_fill_level(void);
    
    //## auto_generated
    ~UC_Citizen_check_fill_level(void);
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedUC_Citizen_check_fill_level : virtual public AOMInstance {
    DECLARE_META(UC_Citizen_check_fill_level, OMAnimatedUC_Citizen_check_fill_level)
};
//#]
#endif // _OMINSTRUMENT

#endif
/*********************************************************************
	File Path	: DefaultComponent\Garbage_Bin_Simulation\UC_Citizen_check_fill_level.h
*********************************************************************/
