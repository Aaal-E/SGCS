/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: Garbage_Bin_Simulation
	Model Element	: UC_Citizen_check_fill_level
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\Garbage_Bin_Simulation\UC_Citizen_check_fill_level.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "UC_Citizen_check_fill_level.h"
//#[ ignore
#define BDD_UC_Citizen_check_fill_level_UC_Citizen_check_fill_level_SERIALIZE OM_NO_OP
//#]

//## package BDD

//## class UC_Citizen_check_fill_level
UC_Citizen_check_fill_level::UC_Citizen_check_fill_level(void) {
    NOTIFY_CONSTRUCTOR(UC_Citizen_check_fill_level, UC_Citizen_check_fill_level(), 0, BDD_UC_Citizen_check_fill_level_UC_Citizen_check_fill_level_SERIALIZE);
}

UC_Citizen_check_fill_level::~UC_Citizen_check_fill_level(void) {
    NOTIFY_DESTRUCTOR(~UC_Citizen_check_fill_level, true);
}

#ifdef _OMINSTRUMENT
IMPLEMENT_META_P(UC_Citizen_check_fill_level, BDD, BDD, false, OMAnimatedUC_Citizen_check_fill_level)
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: DefaultComponent\Garbage_Bin_Simulation\UC_Citizen_check_fill_level.cpp
*********************************************************************/
