/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: UC_Citizen_deposit_garbage
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\DefaultConfig\UC_Citizen_deposit_garbage.cpp
*********************************************************************/

//## auto_generated
#include "UC_Citizen_deposit_garbage.h"
//## package BDD

//## class UC_Citizen_deposit_garbage
UC_Citizen_deposit_garbage::UC_Citizen_deposit_garbage(void) {
}

UC_Citizen_deposit_garbage::~UC_Citizen_deposit_garbage(void) {
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\UC_Citizen_deposit_garbage.cpp
*********************************************************************/
