/*********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: UC_System_overview
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\DefaultConfig\UC_System_overview.h
*********************************************************************/

#ifndef UC_System_overview_H
#define UC_System_overview_H

//## auto_generated
#include <oxf.h>
//## auto_generated
#include "BDD.h"
//## package BDD

//## class UC_System_overview
class UC_System_overview {
    ////    Constructors and destructors    ////
    
public :

    //## auto_generated
    UC_System_overview(void);
    
    //## auto_generated
    ~UC_System_overview(void);
};

#endif
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\UC_System_overview.h
*********************************************************************/
