/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: block_39
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\DefaultConfig\block_39.cpp
*********************************************************************/

//## auto_generated
#include "block_39.h"
//## package BDD

//## class block_39
block_39::block_39(void) {
}

block_39::~block_39(void) {
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\block_39.cpp
*********************************************************************/
