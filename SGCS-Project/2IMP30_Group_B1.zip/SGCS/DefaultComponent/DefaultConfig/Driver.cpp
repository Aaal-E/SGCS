/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Driver
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\DefaultConfig\Driver.cpp
*********************************************************************/

//## auto_generated
#include "Driver.h"
//## package UCs

//## actor Driver
Driver::Driver(void) {
}

Driver::~Driver(void) {
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Driver.cpp
*********************************************************************/
