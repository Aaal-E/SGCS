/********************************************************************
	Rhapsody	: 9.0 
	Login		: 20192435
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: Software_Controllers
//!	Generated Date	: Wed, 12, Jul 2023  
	File Path	: DefaultComponent\DefaultConfig\Software_Controllers.cpp
*********************************************************************/

//## auto_generated
#include "Software_Controllers.h"
//## package BDD

//## class Software_Controllers
Software_Controllers::Software_Controllers(void) {
}

Software_Controllers::~Software_Controllers(void) {
}

const UC_Citizen_check_fill_level* Software_Controllers::getItsUC_Citizen_check_fill_level(void) const {
    return &itsUC_Citizen_check_fill_level;
}

const UC_Citizen_deposit_garbage* Software_Controllers::getItsUC_Citizen_deposit_garbage(void) const {
    return &itsUC_Citizen_deposit_garbage;
}

const UC_Collect_garbage* Software_Controllers::getItsUC_Collect_garbage(void) const {
    return &itsUC_Collect_garbage;
}

const UC_Plan_route* Software_Controllers::getItsUC_Plan_route(void) const {
    return &itsUC_Plan_route;
}

const UC_System_overview* Software_Controllers::getItsUC_System_overview(void) const {
    return &itsUC_System_overview;
}

/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\Software_Controllers.cpp
*********************************************************************/
